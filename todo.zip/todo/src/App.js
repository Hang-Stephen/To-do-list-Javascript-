import React, {useState} from 'react';
import DisplayTasks from './components/DisplayTasks';
import Tasks from './components/Tasks';
import './App.css';

function App() {
  const [currentTask, setCurrentTask] = useState([]);

  return (
    <div className ="App">
      <Tasks currentTask={currentTask} setCurrentTask = {setCurrentTask}/>
      <DisplayTasks currentTask={currentTask} setCurrentTask = {setCurrentTask}/>
    </div>
  );
}

export default App;
