import React, {useState} from 'react';

const DisplayTasks = (props) => {

    const {currentTask,setCurrentTask } = props;

    const handleChecked = (task) => {
        task.markedDelete = !task.markedDelete;
        let updateTasks = [...currentTask];
        setCurrentTask(updateTasks);
    }

    const style = (markedDelete) => {
        if(markedDelete === true){
            return "completed"
        }
        else{
            return "incomplete"
        }
    }

    const deleteThis = (textMessage) => {
        setCurrentTask(
            currentTask.filter((task, index) => {
                return task.text !== textMessage;

                
            })
        )
    }

    return (
        <div>
            {
                currentTask.map((task, index)=> (
                    <div className = {style(task.markedDelete)} key = {index}>
                        <h3>{task.text}</h3>
                        <input type ="checkbox" onChange = {(e) => handleChecked(task)}/>
                        <button onClick = {(e) => deleteThis(task.text)}>Delete</button>
                    </div>
                ))
            }
        </div>
    );
};

export default DisplayTasks;