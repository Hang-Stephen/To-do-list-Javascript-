import React, {useState} from 'react';

const Tasks = (props) => {
    const [task, setTask] = useState("");

    const {currentTask,setCurrentTask } = props;

    const handleSubmit = (e) => {
        e.preventDefault();
        
        setCurrentTask([...currentTask, {
            text: task, 
            markedDelete: false
        }])

        setTask("");
    };

    return (
        <form onSubmit = { handleSubmit }>
            <input onChange = { (e) => setTask(e.target.value)} value = {task} type = "text"/>
            <input type = "submit" value = "Add"/>
        </form>
    )
}

export default Tasks;